package com.example.p1jorge.repository;

import com.example.p1jorge.domain.Servicio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface ServicioRepository extends JpaRepository<Servicio, Integer> {
    @Query(value="SELECT * FROM Servicio WHERE precio <= ?1", nativeQuery = true)
    List<Servicio> findAffordable(double maxPrice);

    @Query(value="SELECT nombre, precio FROM Servicio ORDER BY precio DESC LIMIT 5", nativeQuery = true)
    List<Object[]> top5Expensive();
}
