package com.example.p1jorge.controller;

import com.example.p1jorge.domain.Cita;
import com.example.p1jorge.repository.CitaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/citas")
public class CitaController {

    @Autowired
    private CitaRepository repo;

    @GetMapping
    public List<Cita> all() {
        return repo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Cita> get(@PathVariable int id) {
        return repo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/fecha/{fecha}")
    public List<Cita> byFecha(@PathVariable String fecha) {
        try {
            return repo.findByFecha(LocalDate.parse(fecha));
        } catch (Exception e) {
            return List.of();
        }
    }

    @GetMapping("/servicio/{id}/{from}")
    public List<Cita> byServFrom(@PathVariable int id, @PathVariable String from) {
        try {
            return repo.findByServicioAndFromDate(id, LocalDate.parse(from));
        } catch (Exception e) {
            return List.of();
        }
    }

    @PostMapping
    public Cita create(@RequestBody Cita c) {
        return repo.save(c);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Cita> update(@PathVariable int id, @RequestBody Cita c) {
        if (!repo.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        c.setIdCita(id);
        return ResponseEntity.ok(repo.save(c));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        if (!repo.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}