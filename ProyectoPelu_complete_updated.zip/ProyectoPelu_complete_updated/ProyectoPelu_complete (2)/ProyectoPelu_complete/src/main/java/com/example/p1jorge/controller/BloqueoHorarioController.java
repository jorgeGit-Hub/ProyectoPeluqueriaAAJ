package com.example.p1jorge.controller;

import com.example.p1jorge.domain.BloqueoHorario;
import com.example.p1jorge.repository.BloqueoHorarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bloqueos")
public class BloqueoHorarioController {

    @Autowired
    private BloqueoHorarioRepository repo;

    @GetMapping
    public List<BloqueoHorario> all() {
        return repo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<BloqueoHorario> get(@PathVariable int id) {
        return repo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/admin/{id}")
    public List<BloqueoHorario> byAdmin(@PathVariable int id) {
        return repo.findByAdmin(id);
    }

    @PostMapping
    public BloqueoHorario create(@RequestBody BloqueoHorario b) {
        return repo.save(b);
    }

    @PutMapping("/{id}")
    public ResponseEntity<BloqueoHorario> update(@PathVariable int id, @RequestBody BloqueoHorario b) {
        if (!repo.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        b.setIdBloqueo(id);
        return ResponseEntity.ok(repo.save(b));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable int id) {
        if (!repo.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}