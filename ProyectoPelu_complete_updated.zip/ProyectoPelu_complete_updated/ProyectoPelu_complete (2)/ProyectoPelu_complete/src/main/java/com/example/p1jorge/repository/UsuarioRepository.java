package com.example.p1jorge.repository;

import com.example.p1jorge.domain.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {
    // CORREGIDO: cambiar 'email' por 'correo' para que coincida con el nombre de columna
    @Query(value="SELECT * FROM Usuario WHERE correo = :correo", nativeQuery = true)
    Usuario findByEmail(@Param("correo") String correo);

    @Query(value="SELECT * FROM Usuario WHERE rol = 'cliente'", nativeQuery = true)
    List<Usuario> findAllClientes();

    @Query(value="SELECT COUNT(*) FROM Usuario WHERE rol = 'alumno'", nativeQuery = true)
    int countAlumnos();
}